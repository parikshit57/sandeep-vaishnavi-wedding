(() => {
 const W=window.WEDDING, T=window.I18N; let lang="en", opened=false, musicOn=false;
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const tr=k=>T[lang][k]||k;
 function setLang(next){lang=next;document.documentElement.lang=lang==="hi"?"hi":"en";$$("[data-i18n]").forEach(el=>el.textContent=tr(el.dataset.i18n));$("#langToggle").textContent=tr("language");$("#gateLang").textContent=tr("language");}
 function toggleLang(){setLang(lang==="en"?"hi":"en")}
 $("#langToggle").addEventListener("click",toggleLang);$("#gateLang").addEventListener("click",toggleLang);
 $$("[data-couple]").forEach(el=>{const k=el.dataset.couple;el.textContent=W.couple[k]});
 if(location.hash==="#bride"){document.body.classList.add("bride-side");}
 function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
 function petals(){if(matchMedia("(prefers-reduced-motion: reduce)").matches)return;for(let i=0;i<42;i++){const p=document.createElement("i");p.className="petal "+(["","gold","white"][i%3]);p.style.left=Math.random()*100+"vw";p.style.setProperty("--drift",(Math.random()*180-90)+"px");p.style.animationDuration=(4+Math.random()*5)+"s";p.style.animationDelay=(Math.random()*1.8)+"s";document.body.append(p);setTimeout(()=>p.remove(),11000)}}
 $("#openGate").addEventListener("click",()=>{if(opened)return;opened=true;$("#gate").classList.add("opened");petals();startMusic();setTimeout(()=>$("#gate").remove(),2200)});
 const audio=$("#bgMusic"); if(W.media.music)audio.src=W.media.music;
 async function startMusic(){if(!audio.src)return;audio.volume=.5;try{await audio.play();musicOn=true;$("#musicToggle").textContent="Ⅱ"}catch(e){toast("Tap music to start audio")}}
 $("#musicToggle").addEventListener("click",async()=>{if(!audio.src){toast("Wedding music is not available");return}if(audio.paused){await audio.play();musicOn=true;$("#musicToggle").textContent="Ⅱ"}else{audio.pause();musicOn=false;$("#musicToggle").textContent="♫"}});
 document.addEventListener("visibilitychange",()=>{if(document.hidden&&!audio.paused)audio.pause()});
 function renderEvents(){
  const list=$("#eventList");list.innerHTML="";
  W.events.forEach(ev=>{const card=document.createElement("article");card.className="event-card";
   const day=lang==="hi"?ev.dayHindi:ev.day;
   card.innerHTML=`<span class="event-date">${day.toUpperCase()} · ${new Date(ev.date+"T12:00:00").toLocaleDateString(lang==="hi"?"hi-IN":"en-IN",{day:"numeric",month:"long",year:"numeric"})}</span><h3>${lang==="hi"?ev.title:ev.titleEn}</h3><p>◷ ${ev.time}</p><p>⌖ ${ev.venue}</p><p>${ev.address}</p>${ev.extra.map(x=>`<p class="muted">${x}</p>`).join("")}<div class="event-actions"></div>`;
   const actions=card.querySelector(".event-actions");
   if(ev.mapQuery){const a=document.createElement("a");a.href="https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(ev.mapQuery);a.target="_blank";a.rel="noopener";a.textContent=tr("directions");actions.append(a)}
   const cal=document.createElement("a");cal.href=calendarUrl(ev);cal.download=`${ev.id}.ics`;cal.textContent=tr("calendar");actions.append(cal);
   list.append(card);
  });
 }
 function calendarUrl(ev){const start=ev.date.replaceAll("-","");const dt=new Date(ev.date+"T00:00:00");dt.setDate(dt.getDate()+1);const end=dt.toISOString().slice(0,10).replaceAll("-","");const ics=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Sandeep Vaishnavi//Wedding//EN","BEGIN:VEVENT","UID:"+ev.id+"@sandeep-vaishnavi","DTSTAMP:20261103T000000Z","DTSTART;VALUE=DATE:"+start,"DTEND;VALUE=DATE:"+end,"SUMMARY:"+ev.titleEn+" - Sandeep & Vaishnavi","DESCRIPTION:"+ev.time+" · "+ev.address,"LOCATION:"+ev.venue+", "+ev.address,"END:VEVENT","END:VCALENDAR"].join("\\r\\n");return URL.createObjectURL(new Blob([ics],{type:"text/calendar"}))}
 renderEvents();
 const phones=$("#phoneList");W.family.rsvpPhones.forEach(n=>{const a=document.createElement("a");a.className="phone";a.href="tel:"+n;a.textContent=n;phones.append(a)});
 $("#bestList").textContent=W.family.bestCompliments.join(" · ");
 function countdown(){const target=new Date("2026-11-21T00:00:00+05:30").getTime(),now=Date.now(),d=Math.max(0,target-now),vals={days:Math.floor(d/86400000),hours:Math.floor(d%86400000/3600000),minutes:Math.floor(d%3600000/60000),seconds:Math.floor(d%60000/1000)};Object.entries(vals).forEach(([k,v])=>$("#"+k).textContent=String(v).padStart(2,"0"))}
 countdown();setInterval(countdown,1000);
 $$(".gallery-item").forEach(b=>b.addEventListener("click",()=>{$("#lightboxImage").src=b.dataset.image;$("#lightbox").classList.add("open")}));
 $("#closeLightbox").addEventListener("click",()=>$("#lightbox").classList.remove("open"));$("#lightbox").addEventListener("click",e=>{if(e.target.id==="lightbox")e.currentTarget.classList.remove("open")});
 $("#shareBtn").addEventListener("click",async()=>{const data={title:"Sandeep & Vaishnavi — Shubh Vivah",text:"With love, we invite you to celebrate Sandeep & Vaishnavi · 21 November 2026",url:location.href};if(navigator.share){try{await navigator.share(data)}catch(e){}}else location.href="https://wa.me/?text="+encodeURIComponent(data.text+" "+data.url)});
 $("#copyBtn").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(location.href);toast("Invitation link copied")}catch(e){toast("Copy this page URL from your browser")}});$("#pdfBtn").addEventListener("click",()=>window.print());
 const film=W.media.film;if(film){$("#filmBlock").hidden=false;$("#filmVideo").src=film;$("#playFilm").addEventListener("click",()=>{audio.pause();$("#filmVideo").play()});$("#filmVideo").addEventListener("play",()=>audio.pause())}
 // Deep-link bride view: order names and invitation side can be customized without changing the source wording.
 if(location.hash==="#bride"){
  document.querySelectorAll(".couple-name").forEach(el=>{const a=el.children[0],b=el.children[2];el.insertBefore(b,a)});
  if(W.brideSide.hostsHindi)document.querySelector(".stationery h3").textContent=W.brideSide.hostsHindi;
  if(W.brideSide.invitationHindi)document.querySelector(".stationery-body").textContent=W.brideSide.invitationHindi;
}
})();