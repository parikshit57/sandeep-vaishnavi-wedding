window.WEDDING = {
  "couple": {
    "groom": "Sandeep",
    "bride": "Vaishnavi (Deepa)",
    "groomHindi": "संदीप",
    "brideHindi": "वैष्णवी (दीपा)",
    "city": "Hathin, Haryana",
    "dateISO": "2026-11-21",
    "dateEnglish": "Saturday, 21 November 2026",
    "dateHindi": "शनिवार, दिनांक 21 नवम्बर 2026"
  },
  "family": {
    "hostsHindi": "श्रीमती कुसुमलता एवं श्री राज सिंह",
    "groomLineageHindi": "सुपोत्र स्व० श्री दुर्गा प्रसाद",
    "brideLineageHindi": "सुपुत्री श्रीमती शारदा देवी एवं श्री सतीश कुमार ग्रामी",
    "invitationHindi": "परमपिता परमेश्वर की असीम कृपा से श्रीमती कुसुमलता एवं श्री राज सिंह अपने सुपुत्र चि० संदीप के “परिणय सूत्र बन्धन” की मधुर बेला पर आपको अपने निवास स्थान वार्ड नं 1, नजदीक पंचायत घर, जाटौली, तह० पटौदी, जिला गुरुग्राम (हरि०) पर सादर आमंत्रित करते हैं।",
    "closingHindi": "विनीत: समस्त परिवार एवं मित्रगण",
    "bestComplimentsHeading": "दर्शनाभिलाषी",
    "bestCompliments": [
      "प्रहलाद राय जी",
      "राधेश्याम, सुशील, कृष्णा",
      "मोहन लाल, बाबू (चेयरमैन)",
      "शेरसिंह, भीम, प्रवीण, रिंकू, जोगेन्द्र",
      "हेमन्त, शीतु, कुलदीप, सोनू, देवेन्द्र",
      "नवीन, प्रशांत, कमल, सन्नी, जतिन",
      "मयंक, शुभम, गौरव, दक्ष, माधव, हर्ष"
    ],
    "rsvpName": "राज सिंह (चिल्लू) – पब्लिक हेल्थ विभाग",
    "rsvpAddressHindi": "वार्ड नं 1, नजदीक पंचायत घर, जाटौली, तह० पटौदी, जिला गुरुग्राम (हरियाणा)",
    "rsvpPhones": [
      "9416333551",
      "9991193551",
      "9671740699",
      "9050552330",
      "8168017944"
    ]
  },
  "events": [
    {
      "id": "19nov",
      "date": "2026-11-19",
      "day": "Thursday",
      "dayHindi": "वीरवार",
      "title": "लग्न / टीका",
      "titleEn": "Lagna / Tika",
      "time": "3:15 PM",
      "venue": "रोशन पैलेस",
      "address": "कुलाना रोड, गवर्नमेंट कॉलेज के सामने, जाटौली-मंडी, गुरुग्राम",
      "mapQuery": "Roshan Palace, Kulana Road, Jatauli Mandi, Gurugram, Haryana",
      "extra": [
        "भात — 4:15 PM",
        "प्रीतिभोज — 6:15 PM"
      ]
    },
    {
      "id": "20nov",
      "date": "2026-11-20",
      "day": "Friday",
      "dayHindi": "शुक्रवार",
      "title": "चाक",
      "titleEn": "Chak",
      "time": "4:15 PM",
      "venue": "कार्यक्रम स्थल का नाम कार्ड पर नहीं दिया गया",
      "address": "कार्यक्रम स्थल की जानकारी उपलब्ध नहीं",
      "mapQuery": "",
      "extra": []
    },
    {
      "id": "21nov",
      "date": "2026-11-21",
      "day": "Saturday",
      "dayHindi": "शनिवार",
      "title": "घुड़चढ़ी एवं बारात प्रस्थान",
      "titleEn": "Ghurchadhi & Baraat Departure",
      "time": "2:15 PM · 4:15 PM",
      "venue": "कुटी मंदिर हथीन",
      "address": "वार्ड नं 7, BSNL टेलीफोन एक्सचेंज, गहलब रोड, हथीन, जिला पलवल (हरियाणा)",
      "mapQuery": "Kuti Mandir, Gahlab Road, Hathin, Palwal, Haryana",
      "extra": [
        "बारात प्रस्थान — 4:15 PM"
      ],
      "note": "Pheras / शुभ मुहूर्त का सटीक समय कार्ड पर नहीं दिया गया है।"
    }
  ],
  "reception": {
    "date": "",
    "time": "",
    "venue": "",
    "address": "",
    "note": "Reception details were not present on the supplied invitation."
  },
  "media": {
    "music": "assets/royal-wedding-ambient.mp3",
    "film": "",
    "gallery": [
      "assets/invitation-cover.jpg",
      "assets/family-invitation.jpg",
      "assets/wedding-program.jpg"
    ]
  },
  "timezone": "Asia/Kolkata",
  "brideSide": {
    "hostsHindi": "",
    "invitationHindi": "",
    "note": "Bride-side host wording was not present in the supplied cards; add it here when provided."
  }
};
