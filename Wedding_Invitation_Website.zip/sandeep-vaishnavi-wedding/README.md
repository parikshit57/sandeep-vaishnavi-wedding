# Sandeep & Vaishnavi — Shubh Vivah

A mobile-first static wedding invitation website. Deploy the folder to GitHub Pages, Netlify, or any static host.

## Files
- `index.html` — page structure and Open Graph metadata
- `style.css` — responsive royal sandstone / ivory design, gate animation, reduced-motion support
- `config.js` — all wedding names, dates, venues, family wording, RSVP contacts and media paths
- `i18n.js` — English / Hindi interface strings
- `app.js` — gate, countdown, event cards, calendar downloads, share, print-to-PDF, gallery lightbox and optional media
- `assets/` — the three supplied card photos, cropped Ganesha emblem, and original 52-second ambient wedding instrumental

## Publish
Upload the contents of this folder to a GitHub repository and enable GitHub Pages (Settings → Pages → Deploy from branch), or drag the folder into Netlify Drop.

## Important details to complete
The original invitation does **not** print a reception schedule, a Pheras muhurat time, or a separate 20 November venue. The countdown is date-only and calendar downloads are all-day entries so no unprinted event times are fabricated. These have deliberately not been invented. Update the corresponding values in `config.js` when confirmed.
- Background music is already included as `assets/royal-wedding-ambient.mp3`. It is an original, wordless Indian-inspired ambient instrumental composed for this invitation; no third-party song or film recording is used.
- Add the invitation video at `assets/invitation-film.mp4`, then set `media.film` to that path.
- Replace/adjust the 20 November venue if the family confirms it.
- Update `couple.city` if a different city label is preferred.
- If you want an exact live countdown to the Pheras, enter the confirmed local muhurat time and update the target in `app.js`. The current timer counts to the start of the printed wedding date only; it does not claim to represent the Pheras muhurat.

## Exact-source note
The names, host line, printed dates, times, addresses, and RSVP numbers were transcribed from the supplied invitation photos. The printer number on the card is not treated as an RSVP contact.
